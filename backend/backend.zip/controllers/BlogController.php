<?php

declare(strict_types=1);

namespace Backend\Controllers;

use Backend\Models\BlogPost;
use Backend\Utils\ActivityLogger;
use Backend\Utils\Cache;
use Backend\Utils\Response;
use Backend\Utils\Validator;

require_once __DIR__ . '/BaseCrudController.php';
require_once __DIR__ . '/../models/BlogPost.php';
require_once __DIR__ . '/../utils/ActivityLogger.php';
require_once __DIR__ . '/../utils/Cache.php';
require_once __DIR__ . '/../utils/Response.php';
require_once __DIR__ . '/../utils/Validator.php';

final class BlogController extends BaseCrudController
{
    protected string $modelClass = BlogPost::class;
    protected string $resourceName = 'blog';
    protected array $requiredCreateFields = ['title', 'content_html'];

    public function store(array $params = []): void
    {
        $model = new BlogPost();
        $raw = $this->body();
        $payload = Validator::sanitizeInput($raw);
        $payload['content_html'] = isset($raw['content_html']) ? trim((string) $raw['content_html']) : '';

        $errors = Validator::required($payload, $this->requiredCreateFields);
        if ($errors !== []) {
            Response::error('Validation failed', 422, ['fields' => $errors]);
        }

        if (isset($payload['title']) && (!isset($payload['slug']) || trim((string) $payload['slug']) === '')) {
            $payload['slug'] = $this->slugify((string) $payload['title']);
        }

        $id = $model->create($payload);
        ActivityLogger::log($this->currentAdminId(), 'create', $this->resourceName, $id);
        Cache::clearAll();

        Response::success($model->find($id), 'Created successfully', 201);
    }

    public function update(array $params): void
    {
        $id = (int) ($params['id'] ?? 0);
        if ($id <= 0) {
            Response::error('Invalid resource ID', 422);
        }

        $model = new BlogPost();
        if (!$model->find($id)) {
            Response::error('Resource not found', 404);
        }

        $raw = $this->body();
        $payload = Validator::sanitizeInput($raw);
        if (array_key_exists('content_html', $raw)) {
            $payload['content_html'] = trim((string) $raw['content_html']);
        }

        if (isset($payload['title']) && (!isset($payload['slug']) || trim((string) $payload['slug']) === '')) {
            $payload['slug'] = $this->slugify((string) $payload['title']);
        }

        $ok = $model->update($id, $payload);
        if (!$ok) {
            Response::error('No changes were applied', 422);
        }

        ActivityLogger::log($this->currentAdminId(), 'update', $this->resourceName, $id);
        Cache::clearAll();

        Response::success($model->find($id), 'Updated successfully');
    }

    public function publicShowBySlug(array $params): void
    {
        $slug = (string) ($params['slug'] ?? '');
        if ($slug === '') {
            Response::error('Invalid slug', 422);
        }

        $post = Cache::remember('public:blog:slug:' . $slug, static function () use ($slug) {
            $model = new BlogPost();
            return $model->findBySlug($slug);
        });

        if (!$post || ($post['status'] ?? 'inactive') !== 'active') {
            Response::error('Blog post not found', 404);
        }

        Response::success($post, 'Fetched successfully');
    }
}
