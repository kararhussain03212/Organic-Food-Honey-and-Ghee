<?php

declare(strict_types=1);

use Backend\Config\Database;
use Backend\Config\Env;

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/env.php';

Env::load(dirname(__DIR__) . '/.env');

$pdo = Database::connection();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$pdo->exec("
CREATE TABLE IF NOT EXISTS page_meta_descriptions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    page_key ENUM('home','about','product','blog','contact','order') NOT NULL UNIQUE,
    meta_description VARCHAR(320) NOT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$rows = [
    'home' => 'Shop the best organic food online in Pakistan. We offer pure Sidr honey, grass-fed desi ghee, cold-pressed oils, and farm-fresh groceries delivered nationwide.',
    'about' => 'Discover the story behind Swift Sign Organic. Learn how we source raw Arion Honey and extract Golden Cow Ghee to provide lab-tested, chemical-free food.',
    'product' => 'Buy premium organic products online in Pakistan. Browse our complete collection of pure honey and natural desi ghee',
    'blog' => 'Explore expert health, nutrition, and customer experience insights from a trusted Pakistani organic grocery store.',
    'contact' => 'Contact our organic food store in Pakistan for premium natural products, healthy groceries, organic honey, dry fruits, oils, and delivery support.',
    'order' => 'Track your organic food order from Swift Sign General Trading. Enter your order ID to get real-time delivery updates for your pure honey, ghee, and groceries.',
];

$stmt = $pdo->prepare("
    INSERT INTO page_meta_descriptions (page_key, meta_description, status, created_at, updated_at)
    VALUES (:page_key, :meta_description, 'active', NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      meta_description = VALUES(meta_description),
      status = VALUES(status),
      updated_at = NOW()
");

foreach ($rows as $pageKey => $metaDescription) {
    $stmt->execute([
        ':page_key' => $pageKey,
        ':meta_description' => $metaDescription,
    ]);
}

echo "page_meta_descriptions table migration completed successfully." . PHP_EOL;
