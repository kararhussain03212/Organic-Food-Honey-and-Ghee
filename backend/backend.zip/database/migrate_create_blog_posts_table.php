<?php

declare(strict_types=1);

use Backend\Config\Database;
use Backend\Config\Env;

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/env.php';

Env::load(dirname(__DIR__) . '/.env');

$pdo = Database::connection();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(190) NOT NULL,
    slug VARCHAR(190) NOT NULL UNIQUE,
    category VARCHAR(120) NULL,
    read_time VARCHAR(40) NULL,
    excerpt TEXT NULL,
    content_html LONGTEXT NOT NULL,
    featured_image VARCHAR(255) NULL,
    author_name VARCHAR(120) NULL,
    published_at DATETIME NULL,
    order_position INT UNSIGNED NOT NULL DEFAULT 1,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    meta_title VARCHAR(190) NULL,
    meta_description VARCHAR(255) NULL,
    meta_keywords VARCHAR(255) NULL,
    og_image VARCHAR(255) NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;

$pdo->exec($sql);

function columnExists(PDO $pdo, string $table, string $column): bool
{
    $safeTable = preg_replace('/[^a-zA-Z0-9_]/', '', $table) ?: $table;
    $safeColumn = str_replace("'", "\\'", $column);
    $stmt = $pdo->query("SHOW COLUMNS FROM `{$safeTable}` LIKE '{$safeColumn}'");
    if (!$stmt) {
        return false;
    }
    return (bool) $stmt->fetch();
}

if (!columnExists($pdo, 'blog_posts', 'category')) {
    $pdo->exec("ALTER TABLE blog_posts ADD COLUMN category VARCHAR(120) NULL AFTER slug");
}

if (!columnExists($pdo, 'blog_posts', 'read_time')) {
    $pdo->exec("ALTER TABLE blog_posts ADD COLUMN read_time VARCHAR(40) NULL AFTER category");
}

echo "blog_posts table migration completed successfully." . PHP_EOL;
