<?php

declare(strict_types=1);

use Backend\Config\Database;
use Backend\Config\Env;

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/env.php';

Env::load(dirname(__DIR__) . '/.env');

$pdo = Database::connection();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$pdo->exec("
CREATE TABLE IF NOT EXISTS home_blog_posts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    blog_post_id INT UNSIGNED NOT NULL,
    order_position INT UNSIGNED NOT NULL DEFAULT 1,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    UNIQUE KEY uq_home_blog_posts_blog_post_id (blog_post_id),
    INDEX idx_home_blog_posts_order_status (order_position, status),
    CONSTRAINT fk_home_blog_posts_blog_post
        FOREIGN KEY (blog_post_id) REFERENCES blog_posts(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$count = (int) $pdo->query("SELECT COUNT(*) AS aggregate FROM home_blog_posts")->fetch()['aggregate'];
if ($count > 0) {
    echo "home_blog_posts already has data. Skipping seed." . PHP_EOL;
    exit(0);
}

$blogPosts = $pdo->query("
    SELECT id
    FROM blog_posts
    WHERE status = 'active'
    ORDER BY order_position ASC, published_at DESC, id DESC
    LIMIT 3
")->fetchAll();

if (!$blogPosts) {
    echo "No active blog_posts found. Seed skipped." . PHP_EOL;
    exit(0);
}

$stmt = $pdo->prepare("
    INSERT INTO home_blog_posts
    (blog_post_id, order_position, status, created_at, updated_at)
    VALUES
    (:blog_post_id, :order_position, 'active', NOW(), NOW())
");

foreach ($blogPosts as $index => $row) {
    $stmt->execute([
        ':blog_post_id' => (int) $row['id'],
        ':order_position' => $index + 1,
    ]);
}

echo "home_blog_posts seeded successfully." . PHP_EOL;
