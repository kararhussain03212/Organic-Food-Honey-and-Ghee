<?php

declare(strict_types=1);

use Backend\Config\Database;
use Backend\Config\Env;

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/env.php';

Env::load(dirname(__DIR__) . '/.env');

$pdo = Database::connection();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$count = (int) $pdo->query("SELECT COUNT(*) AS aggregate FROM blog_posts")->fetch()['aggregate'];

if ($count > 0) {
    echo "blog_posts already has data. Skipping seed." . PHP_EOL;
    exit(0);
}

$rows = [
    [
        'title' => 'Why Healthy Natural Food Products Matter in Pakistan',
        'slug' => 'healthy-natural-food-products-pakistan',
        'category' => 'Health Blog',
        'read_time' => '8 min read',
        'excerpt' => 'A practical guide for Pakistani families to build healthier food habits with clean pantry choices.',
        'content_html' => '<h2>Start With Everyday Staples</h2><p>Most families do not need dramatic diet changes. Better daily staples can produce long-term health gains.</p><h2>Build a Weekly Routine</h2><p>Plan meals, hydration, and portions in advance to improve consistency.</p><h2>Choose Trusted Sources</h2><p>Reliable suppliers with transparent descriptions reduce confusion and increase confidence.</p>',
        'featured_image' => 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1600&q=80',
        'author_name' => 'Honey Ghee Editorial Team',
        'meta_title' => 'Health Blog | Healthy Natural Food Products in Pakistan',
        'meta_description' => 'Learn how healthy natural food products support family nutrition in Pakistan.',
        'meta_keywords' => 'healthy natural food products, organic products pakistan',
    ],
    [
        'title' => 'Smart Nutrition Shopping for Premium Chemical Free Foods',
        'slug' => 'nutrition-guide-premium-chemical-free-foods',
        'category' => 'Nutrition Blog',
        'read_time' => '9 min read',
        'excerpt' => 'A nutrition-first method to compare products, control budget, and improve food quality outcomes.',
        'content_html' => '<h2>Nutrition Starts Before Cooking</h2><p>Shopping decisions directly shape meal quality and long-term nutritional value.</p><h2>Balance Price With Value</h2><p>Cost per serving and ingredient quality should be considered together.</p><h2>Use a Repeatable Framework</h2><p>Apply a consistent checklist for category fit, quality, and stock before checkout.</p>',
        'featured_image' => 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=1600&q=80',
        'author_name' => 'Honey Ghee Editorial Team',
        'meta_title' => 'Nutrition Blog | Premium Chemical Free Foods Pakistan',
        'meta_description' => 'Discover a practical nutrition strategy for buying premium chemical free foods online in Pakistan.',
        'meta_keywords' => 'premium chemical free foods, order organic food online',
    ],
    [
        'title' => 'From Click to Kitchen: Better Customer Experience for Organic Products',
        'slug' => 'customer-experience-organic-products-pakistan',
        'category' => 'Experience Blog',
        'read_time' => '7 min read',
        'excerpt' => 'How a premium online organic store guides users from discovery to delivery with trust and clarity.',
        'content_html' => '<h2>Navigation and Clarity Build Trust</h2><p>Clean categories and clear labels help users choose with confidence.</p><h2>Product Pages Must Answer Questions</h2><p>Availability, stock, and useful descriptions reduce checkout friction.</p><h2>Post-Purchase Support Builds Loyalty</h2><p>Delivery updates and usage guidance create strong repeat relationships.</p>',
        'featured_image' => 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=1600&q=80',
        'author_name' => 'Honey Ghee Editorial Team',
        'meta_title' => 'Experience Blog | Organic Products Pakistan Journey',
        'meta_description' => 'Explore the ideal customer journey for ordering organic products online in Pakistan.',
        'meta_keywords' => 'organic grocery store pakistan, buy organic products online',
    ],
];

$stmt = $pdo->prepare('
    INSERT INTO blog_posts
    (title, slug, category, read_time, excerpt, content_html, featured_image, author_name, published_at, order_position, status, meta_title, meta_description, meta_keywords, og_image, created_at, updated_at)
    VALUES
    (:title, :slug, :category, :read_time, :excerpt, :content_html, :featured_image, :author_name, NOW(), :order_position, :status, :meta_title, :meta_description, :meta_keywords, :og_image, NOW(), NOW())
');

foreach ($rows as $index => $row) {
    $stmt->execute([
        ':title' => $row['title'],
        ':slug' => $row['slug'],
        ':category' => $row['category'],
        ':read_time' => $row['read_time'],
        ':excerpt' => $row['excerpt'],
        ':content_html' => $row['content_html'],
        ':featured_image' => $row['featured_image'],
        ':author_name' => $row['author_name'],
        ':order_position' => $index + 1,
        ':status' => 'active',
        ':meta_title' => $row['meta_title'],
        ':meta_description' => $row['meta_description'],
        ':meta_keywords' => $row['meta_keywords'],
        ':og_image' => $row['featured_image'],
    ]);
}

echo "Blog posts seeded successfully." . PHP_EOL;
