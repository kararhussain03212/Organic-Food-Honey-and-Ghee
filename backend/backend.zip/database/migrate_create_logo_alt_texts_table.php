<?php

declare(strict_types=1);

use Backend\Config\Database;
use Backend\Config\Env;

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/env.php';

Env::load(dirname(__DIR__) . '/.env');

$pdo = Database::connection();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS logo_alt_texts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    logo_key ENUM('nav_logo', 'footer_logo') NOT NULL UNIQUE,
    alt_text VARCHAR(255) NOT NULL,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;

$pdo->exec($sql);

$stmt = $pdo->prepare('
    INSERT INTO logo_alt_texts (logo_key, alt_text, status, created_at, updated_at)
    VALUES (:logo_key, :alt_text, :status, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      alt_text = VALUES(alt_text),
      status = VALUES(status),
      updated_at = NOW()
');

$stmt->execute([
    ':logo_key' => 'nav_logo',
    ':alt_text' => 'Honey Ghee logo',
    ':status' => 'active',
]);

$stmt->execute([
    ':logo_key' => 'footer_logo',
    ':alt_text' => 'Honey Ghee logo',
    ':status' => 'active',
]);

echo "logo_alt_texts table migration completed successfully." . PHP_EOL;
